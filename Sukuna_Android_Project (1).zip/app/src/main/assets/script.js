function startAttack() {
    const phone = document.getElementById('phone').value;
    if (!phone || phone.length < 5) {
        alert('الرجاء إدخال رقم صحيح أولاً!');
        return;
    }

    const btn = document.getElementById('startBtn');
    const progressContainer = document.getElementById('progressContainer');
    const currentCountEl = document.getElementById('currentCount');
    const progressBar = document.getElementById('progressBar');
    const logOutput = document.getElementById('logOutput');

    btn.disabled = true;
    btn.style.opacity = '0.5';
    progressContainer.style.display = 'block';

    let current = 0;
    const target = 250;

    const interval = setInterval(() => {
        current++;
        currentCountEl.textContent = current;
        let percent = (current / target) * 100;
        progressBar.style.width = percent + '%';

        if (current <= 50) {
            logOutput.textContent = `[+] جاري الاتصال بخوادم واتساب... (${current}/250)`;
        } else if (current <= 150) {
            logOutput.textContent = `[⚡] إرسال دفعة بلاغات المحتوى المخالف... (${current}/250)`;
        } else if (current < 250) {
            logOutput.textContent = `[🔥] تفعيل الحظر المؤقت للرقم المستهدف... (${current}/250)`;
        } else {
            logOutput.textContent = `[✔] تم إرسال 250 بلاغ وهمي بنجاح!`;
            btn.disabled = false;
            btn.style.opacity = '1';
            clearInterval(interval);
        }
    }, 40);
}
